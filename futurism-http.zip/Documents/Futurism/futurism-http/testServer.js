require('./config/env.js');
require('./server');