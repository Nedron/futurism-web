if(process.env.SERVO_ID === '1') {
    // delete empty guilds
}