//doesn't work without actual connections to redis and s3'

describe('tests-get', function() {

    /*var mongoose = require('mongoose');
    var mockgoose = require('mockgoose');
    mockgoose(mongoose);

    var testsGet = require('../../routes/testsGet');


    /
    it('should return ok for all tests', function(done) {
        var request = {};
        testsGet(request, {apiOut: function(err, result) {
            expect(result.s3).toContain('pass!');
            expect(result.mongo).toContain('pass!');
            expect(result.redis).toContain('pass!');
            done();
        }});
    });*/

});