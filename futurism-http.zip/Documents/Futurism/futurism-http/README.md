installation
    git submodule update --init
    npm install
    npm start
    
testing
    npm test