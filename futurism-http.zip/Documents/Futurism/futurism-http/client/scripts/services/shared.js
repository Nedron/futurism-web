angular.module('futurism')
    .factory('shared', function() {
        'use strict';
        return window.futurismShared;
    });