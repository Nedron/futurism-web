angular.module('futurism')
    .factory('io', function() {
        'use strict';
        return window.io;
    });