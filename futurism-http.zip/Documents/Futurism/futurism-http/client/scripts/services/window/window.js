angular.module('futurism')
    .factory('window', function() {
        'use strict';
        return window;
    });