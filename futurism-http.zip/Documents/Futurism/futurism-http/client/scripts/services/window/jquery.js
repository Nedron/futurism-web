angular.module('futurism')
    .factory('$', function() {
        'use strict';
        return window.$;
    });