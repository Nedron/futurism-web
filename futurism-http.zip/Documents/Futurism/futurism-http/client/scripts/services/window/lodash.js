angular.module('futurism')
    .factory('_', function() {
        'use strict';
        return window._;
    });